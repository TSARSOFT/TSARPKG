import tkinter

def setup_repo():
    install=tkinter.LabelFrame(root, text='install')
    install.pack(side='left', fill='y')
    exec('select=tkinter.OptionMenu(install, default, \'TSARED\', \'TSARPKG\', \'TSARCTL\')')
